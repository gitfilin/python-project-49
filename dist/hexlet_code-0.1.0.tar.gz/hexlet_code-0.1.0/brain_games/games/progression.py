import random


QUESTION = 'What number is missing in the progression?'


def game_progression():
    result = random.randint(1, 100)
    pass
