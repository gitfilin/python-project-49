import random


QUESTION = 'What number is missing in the progression?'

def game_progression():
    pass